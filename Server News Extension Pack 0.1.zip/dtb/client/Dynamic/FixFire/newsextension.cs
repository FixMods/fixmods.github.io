// VERY shabby code.

function initiateExtendedNewsCodes(%client, %line) {
// Edit this if you wish, to add extra codes.
%nline = %line;
%nline = strreplace(%nline, "<CNAME>", strreplace(strreplace(strreplace(strreplace(strreplace(strreplace(strreplace(strreplace(strreplace(strreplace(colorPlayerName(%client), "\c0", "<color:a5a5a5>"), "\c9", "<color:ff0000>"), "\c8", "<color:b900ff>"), "\c7", "<color:e0ffb0>"), "\c6", "<color:ff9600>"), "\c5", "<color:32f000>"), "\c4", "<color:0096fa>"), "\c3", "<color:ffffff>"), "\c2", "<color:f8cc00>"), "\c1", "<color:ff00ff>"));
return %nline;
}

package serverNewsExtension {
function sendNewsToClient(%client) { %file = new FileObject(); %file.openForRead("tbm/client/ServerNews.hfl"); commandtoclient(%client,'GetServerNews', 0); while(!%file.isEOF()) { schedule(15 * %x++, 0, commandtoclient, %client, 'GetServerNews', 1, initiateExtendedNewsCodes(%client, %file.readline())); } schedule(15 * %x++, 0, commandtoclient, %client, 'GetServerNews', 2); %file.close(); %file.delete(); } //themi
function GameConnection::transmitSettings(%this, %t) {
if(%t $= "" || %t $= "weapons") {
  for(%x = 1; %x <= $weptotal; %x++) {
    if(isObject($weapon[%x])) {
      if($weapon[%x].spawnName !$= "")
        %y = $weapon[%x].spawnName;
      else
        %y = $weapon[%x].invName;
    }
    else
      %y = $weapon[%x];
    schedule(10 * %x, 0, commandToClient, %this, 'ReceiveWeaponName', %y, (%x == 1));
  }
}
if(%t $= "" || %t $= "news") {
  if($Pref::Server::EnableNews && !%this.receivedNews) {
    %x = 0;
    %file = new FileObject();
    %file.openForRead("tbm/client/ServerNews.hfl");
    commandToClient(%this,'GetServerNews', 0);
    while(!%file.isEOF())
      schedule(10 * %x++, 0, commandToClient, %this, 'GetServerNews', 1, initiateExtendedNewsCodes(%this, %file.readline()));
    %file.close();
    %file.delete();
    %this.receivedNews = 1;
  }
}
if(%t $= "" || %t $= "bodytypes") {
  for(%i = 0; %i <= $BodytypeCount; %i++)
    schedule(10 * %i, 0, commandToClient, %this, 'GetBodytype', %i, ($Bodytype[%i].name $= "" ? $Bodytype[%i] : $Bodytype[%i].name));
}
if(%t $= "" || %t $= "switches") {
  for(%i = 1; %i <= $Switch::numTypes; %i++)
    schedule(10 * %i, 0, commandToClient, %this, 'GetSwitchAction', %i, $Switch::Type[%i], $Switch::Name[%i]);
  for(%i = 1; %i <= $Switch::numGroups; %i++)
    schedule(10 * %i, 0, commandToClient, %this, 'GetSwitchGroup', %i, $Switch::Group[%i], $Switch::Groupname[$Switch::Group[%i]]);
}
}
function ServerNewsGUI_SaveNews() {
$ServerNews = strreplace(strreplace(txtServerNewsEditor.getvalue(),"]",">"),"[","<");
%file = new FileObject();
%file.openForwrite("tbm/client/ServerNews.hfl");
%file.writeline($ServerNews);
%file.close();
%file.delete();
txtServerNewsEdit.setvalue(strreplace($ServerNews, "<CNAME>", "CLIENTNAME"));
}
function ServerNewsGUI_LoadNews() {
$ServerNews = "";
%file = new FileObject();
%file.openForRead("tbm/client/ServerNews.hfl");
while(!%file.isEOF()) {
	$ServerNews = $ServerNews@%file.readline()@"\n";
}
%file.close();
%file.delete();
txtServerNewsEdit.setvalue(strreplace($ServerNews, "<CNAME>", "CLIENTNAME"));
txtServerNewsEditor.setvalue(strreplace(strreplace($ServerNews,">","]"),"<","["));
if(!ServerNewsEditorGUI.isAwake())
	canvas.pushDialog(ServerNewsEditorGUI);
}
};
activatePackage(serverNewsExtension);